import pygame
import random

pygame.init()
pygame.font.init()

# Глобальные переменнные
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 700
WIDTH_GAME = 300
HEIGHT_GAME = 600
BLOCK_SIZE = 30

TOP_LEFT_X = (WINDOW_WIDTH - WIDTH_GAME) // 2
TOP_LEFT_Y = WINDOW_HEIGHT - HEIGHT_GAME

backdrop = pygame.image.load('Fon.jpg')
backdrop_game = pygame.image.load('FONGAME.jpg')
try_again = pygame.image.load('gameover.jpg')

music = pygame.mixer.music.load('music.MP3')
pygame.mixer.music.play(-1)

# цвета
GRAY = (119, 118, 110)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 0, 0)
GREEN = (0, 200, 0)
BLUE = (0, 255, 255)
BRIGHT_RED = (255, 0, 0)
BRIGHT_GREEN = (0, 255, 0)
SEA_GREEN = (0, 255, 255)
ORANGE = (255, 165, 0)
YELLOW = (255, 255, 0)
PURPLE = (128, 0, 128)
LIGHT_RED = (255, 0, 0)

SHAPE_COLORS = [(0, 255, 0), (255, 0, 0), (0, 255, 255), (255, 255, 0), (255, 165, 0), (0, 0, 255), (128, 0, 128)]

# Формы фигур
S = [['.....',
      '.....',
      '..00.',
      '.00..',
      '.....'],
     ['.....',
      '..0..',
      '..00.',
      '...0.',
      '.....']]

Z = [['.....',
      '.....',
      '.00..',
      '..00.',
      '.....'],
     ['.....',
      '..0..',
      '.00..',
      '.0...',
      '.....']]

I = [['..0..',
      '..0..',
      '..0..',
      '..0..',
      '.....'],
     ['.....',
      '0000.',
      '.....',
      '.....',
      '.....']]

O = [['.....',
      '.....',
      '.00..',
      '.00..',
      '.....']]

J = [['.....',
      '.0...',
      '.000.',
      '.....',
      '.....'],
     ['.....',
      '..00.',
      '..0..',
      '..0..',
      '.....'],
     ['.....',
      '.....',
      '.000.',
      '...0.',
      '.....'],
     ['.....',
      '..0..',
      '..0..',
      '.00..',
      '.....']]

L = [['.....',
      '...0.',
      '.000.',
      '.....',
      '.....'],
     ['.....',
      '..0..',
      '..0..',
      '..00.',
      '.....'],
     ['.....',
      '.....',
      '.000.',
      '.0...',
      '.....'],
     ['.....',
      '.00..',
      '..0..',
      '..0..',
      '.....']]

T = [['.....',
      '..0..',
      '.000.',
      '.....',
      '.....'],
     ['.....',
      '..0..',
      '..00.',
      '..0..',
      '.....'],
     ['.....',
      '.....',
      '.000.',
      '..0..',
      '.....'],
     ['.....',
      '..0..',
      '.00..',
      '..0..',
      '.....']]

TYPE_SHAPES = [S, Z, I, O, J, L, T]
SHAPE_COLORS = [(0, 255, 0), (255, 0, 0), (0, 255, 255), (255, 255, 0), (255, 165, 0), (0, 0, 255), (128, 0, 128)]


class World(object):
    def __init__(self, x, y, shape):
        self.x = x
        self.y = y
        self.shape = shape
        self.color = SHAPE_COLORS[TYPE_SHAPES.index(shape)]
        self.rotation = 0


def intro_g():
    g_intro = False
    while g_intro == False:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                g_intro = True
                game_over = True

        button(100, 400, 70, 30, 'Играть', WHITE, BRIGHT_RED, RED, 25, 106, 406, gameloop)
        button(600, 400, 70, 30, 'Выход', WHITE, BRIGHT_GREEN, GREEN, 25, 606, 406, quit1)

        pygame.display.update()


def next_g():
    g_intro = False
    while g_intro == False:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                g_intro = True
                game_over = True

        s_width = 900

        message("         Попробывать ещё раз", WHITE, 50, (s_width / 2 - 300), 200)
        button(100, 400, 80, 30, 'Играть', WHITE, BRIGHT_RED, RED, 25, 106, 406, gameloop)
        button(600, 400, 90, 30, 'Выход', WHITE, BRIGHT_GREEN, GREEN, 25, 606, 406, quit1)

        pygame.display.update()


def message(mess, colour, size, x, y):
    font = pygame.font.SysFont(None, size)
    display_text = font.render(mess, True, colour)
    window.blit(display_text, (x, y))
    pygame.display.update()


def button(x, y, w, h, mess, mess_color, actc, noc, size, tx, ty, function):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + w > mouse[0] > x and y + h > mouse[1] > y:

        pygame.draw.rect(window, actc, [x, y, w, h])
        message(mess, mess_color, size, tx, ty)
        pygame.display.update()
        if click == (1, 0, 0):
            function()

    else:
        pygame.draw.rect(window, noc, [x, y, w, h])
        message(mess, mess_color, size, tx, ty)
        pygame.display.update()
    pygame.display.update()


def quit1():
    pygame.quit()
    quit()


def gameloop():
    x = 300
    y = 400
    x_change = 0
    y_change = 0
    global game_over
    game_over = False

    while game_over == False:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    x_change = -10
                elif event.key == pygame.K_RIGHT:
                    x_change = +10
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    x_change = 0

        x += x_change
        main(window)

        pygame.display.update()


def create_grid(locked_pos={}):
    grid = [[(0, 0, 0) for x in range(10)] for x in range(20)]

    for i in range(len(grid)):
        for j in range(len(grid[i])):
            if (j, i) in locked_pos:
                lst = locked_pos[(j, i)]
                grid[i][j] = lst
    return grid


def convert_shape_format(shape):
    positions = []
    form = shape.shape[shape.rotation % len(shape.shape)]

    for i, line in enumerate(form):
        row = list(line)
        for j, column in enumerate(row):
            if column == '0':
                positions.append((shape.x + j, shape.y + i))

    for i, pos in enumerate(positions):
        positions[i] = (pos[0] - 2, pos[1] - 4)

    return positions


def valid_space(shape, grid):
    accepted_pos = [[(j, i) for j in range(10) if grid[i][j] == (BLACK)] for i in range(20)]
    accepted_pos = [j for sub in accepted_pos for j in sub]

    formatted = convert_shape_format(shape)

    for pos in formatted:
        if pos not in accepted_pos:
            if pos[1] > -1:
                return False
    return True


def check_lost(positions):
    for pos in positions:
        x, y = pos
        if y < 1:
            return True

    return False


def get_random_shape():
    return World(5, 0, random.choice(TYPE_SHAPES))


def draw_text_middle(surface, text, size, color):
    font = pygame.font.SysFont("comicsansms", size, bold=True)
    label = font.render(text, 3, color)

    surface.blit(label, (
    TOP_LEFT_X + WIDTH_GAME / - (label.get_width() / 2), TOP_LEFT_Y + HEIGHT_GAME / 2 - label.get_height() / 2))


def draw_text_center(surface, text, size, color):
    font = pygame.font.SysFont("comicsansms", size, bold=True)
    label = font.render(text, 3, color)

    surface.blit(label, (
    TOP_LEFT_X + WIDTH_GAME / 5 - (label.get_width() / 5), TOP_LEFT_Y + HEIGHT_GAME / 5 - label.get_height() / 5))


def draw_text_corner(surface, text, size, color):
    font = pygame.font.SysFont("comicsans", size, bold=True)
    label = font.render(text, 5, color)

    surface.blit(label, (
    TOP_LEFT_X + WIDTH_GAME / 2 - (label.get_width() / 2), TOP_LEFT_Y + HEIGHT_GAME / 2 - label.get_height() / 2))


def draw_grid(surface, grid):
    sx = TOP_LEFT_X
    sy = TOP_LEFT_Y

    for i in range(len(grid)):
        pygame.draw.line(surface, (GRAY), (sx, sy + i * BLOCK_SIZE), (sx + WIDTH_GAME, sy + i * BLOCK_SIZE))
        for j in range(len(grid[i])):
            pygame.draw.line(surface, (GRAY), (sx + j * BLOCK_SIZE, sy), (sx + j * BLOCK_SIZE, sy + HEIGHT_GAME))


def clear_rows(grid, locked):
    inc = 0
    for i in range(len(grid) - 1, -1, -1):
        row = grid[i]
        if (0, 0, 0) not in row:
            inc += 1
            ind = i
            for j in range(len(row)):
                try:
                    del locked[(j, i)]
                except:
                    continue

    if inc > 0:
        for key in sorted(list(locked), key=lambda x: x[1])[::-1]:
            x, y = key
            if y < ind:
                newKey = (x, y + inc)
                locked[newKey] = locked.pop(key)
                pygame.mixer.music.load('linecleared.wav')
                pygame.mixer.music.play()

    return inc


def draw_next_shape(shape, surface):
    font = pygame.font.SysFont("comicsansms", 30, bold=True)
    label = font.render('Cледующая фигура', 1, (0, 0, 0))

    sx = TOP_LEFT_X + WIDTH_GAME + 50
    sy = TOP_LEFT_Y + HEIGHT_GAME / 2 - 100
    format = shape.shape[shape.rotation % len(shape.shape)]

    for i, line in enumerate(format):
        row = list(line)
        for j, column in enumerate(row):
            if column == '0':
                pygame.draw.rect(surface, shape.color,
                                 (sx + j * BLOCK_SIZE, sy + i * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE), 0)

    surface.blit(label, (sx + 10, sy - 30))


def update_score(nscore):
    score = max_points()

    with open('../Тетрис/scores.txt', 'w') as f:
        if int(score) > nscore:
            f.write(str(score))
        else:
            f.write(str(nscore))


def max_points():
    with open('../Тетрис/scores.txt', 'r') as f:
        lines = f.readlines()

        point = lines[0].strip()

    return point


def draw_window(surface, grid, point=0, last_points=0):
    window.blit(backdrop_game, (0, 0))

    pygame.font.init()

    font = pygame.font.SysFont("comicsans", 60, bold=True)
    label = font.render('ТЕТРИС', 1, (BLUE))

    surface.blit(label, (TOP_LEFT_X + WIDTH_GAME / 2 - (label.get_width() / 2), 30))

    # Текущие очки

    font = pygame.font.SysFont("comicsansms", 30, bold=True)
    label = font.render('Очки: ' + str(point), 1, (BLACK))

    sx = TOP_LEFT_X + WIDTH_GAME + 50
    sy = TOP_LEFT_Y + HEIGHT_GAME / 2 - 100

    surface.blit(label, (sx + 20, sy + 160))
    # Последние очки
    font = pygame.font.SysFont("comicsansms", 23, bold=True)
    label = font.render('Лучшие очки: ' + last_points, 1, (0, 0, 0))

    sx = TOP_LEFT_X - 200
    sy = TOP_LEFT_Y + 200

    surface.blit(label, (sx + 1, sy + 160))

    for i in range(len(grid)):
        for j in range(len(grid[i])):
            pygame.draw.rect(surface, grid[i][j],
                             (TOP_LEFT_X + j * BLOCK_SIZE, TOP_LEFT_Y + i * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE),
                             0)

    pygame.draw.rect(surface, (200, 0, 0), (TOP_LEFT_X, TOP_LEFT_Y, WIDTH_GAME, HEIGHT_GAME), 5)

    draw_grid(surface, grid)
    pygame.display.update()


def main(window):
    last_score = max_points()
    lock_pos = {}
    grid = create_grid(lock_pos)

    rep_elem = False
    run = True
    cur_elem = get_random_shape()
    next_elem = get_random_shape()
    clock = pygame.time.Clock()
    drop_time = 0
    drop_speed = 0.30
    complete_time = 0
    score = 0

    while run:
        grid = create_grid(lock_pos)
        drop_time += clock.get_rawtime()
        complete_time += clock.get_rawtime()
        clock.tick()

        if complete_time / 1000 > 5:
            complete_time = 0
            if complete_time > 0.12:
                complete_time -= 0.005

        if drop_time / 1000 > drop_speed:
            drop_time = 0
            cur_elem.y += 1
            if not (valid_space(cur_elem, grid)) and cur_elem.y > 0:
                cur_elem.y -= 1
                rep_elem = True

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.display.quit()
                exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    cur_elem.x -= 1
                    if not (valid_space(cur_elem, grid)):
                        cur_elem.x += 1
                if event.key == pygame.K_RIGHT:
                    cur_elem.x += 1
                    if not (valid_space(cur_elem, grid)):
                        cur_elem.x -= 1
                if event.key == pygame.K_DOWN:
                    cur_elem.y += 1
                    if not (valid_space(cur_elem, grid)):
                        cur_elem.y -= 1
                if event.key == pygame.K_UP:
                    cur_elem.rotation += 1
                    if not (valid_space(cur_elem, grid)):
                        cur_elem.rotation -= 1

        shape_pos = convert_shape_format(cur_elem)

        for i in range(len(shape_pos)):
            x, y = shape_pos[i]
            if y > -1:
                grid[y][x] = cur_elem.color

        if rep_elem:
            for pos in shape_pos:
                p = (pos[0], pos[1])
                lock_pos[p] = cur_elem.color
            cur_elem = next_elem
            next_elem = get_random_shape()
            rep_elem = False
            score += clear_rows(grid, lock_pos) * 10

        draw_window(window, grid, score, last_score)
        draw_next_shape(next_elem, window)
        pygame.display.update()

        if check_lost(lock_pos):
            pygame.mixer.music.load('gameover.wav')
            pygame.mixer.music.play()
            draw_text_middle(window, "Заново", 80, (BLUE))
            pygame.display.update()

            pygame.time.delay(1500)
            run = False
            update_score(score)

            window.blit(try_again, (0, 0))
            next_g()
            paygame.quit()
            quit()


def main_menu(Window):
    run = True
    while run:
        Window.fill((255, 255, 255))
        Window.blit(backdrop, (0, 0))
        intro_g()
        paygame.quit()
        quit()
        main(Window)

    pygame.display.quit()


window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Тетрис')
main_menu(window)
